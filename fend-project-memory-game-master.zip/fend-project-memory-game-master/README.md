# Memory Game Project

user has to choose evey matched couple of cards in one move to win.


## Instructions

The starter project has some HTML and CSS styling to display a static version of the Memory Game project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

## Refrences

udacity front-end web developer courses and many search and tutorials.
